var rect = div.getBoundingClientRect();
console.log(rect.top, rect.right, rect.bottom, rect.left);